import "./apple.css";

export const Apple = () => {
  return (
    <ul className="apple-task-bar">
      <li className="red-col"></li>
      <li className="sunred-col"></li>
      <li className="green-col"></li>
    </ul>
  );
};
